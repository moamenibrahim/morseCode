#!/bin/bash
set -ex

python -m tests.morse_tests;
